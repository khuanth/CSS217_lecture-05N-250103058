@echo off
cd /d "%~dp0"
if not exist out mkdir out
(for /r src %%f in (*.java) do @echo "%%f") > sources.txt
(for /r tests %%f in (*.java) do @echo "%%f") >> sources.txt
javac -encoding UTF-8 -d out @sources.txt
if errorlevel 1 exit /b 1
for %%n in (1 2 3 4 5) do (
    java -Duser.language=en -Duser.country=US -cp out task%%n.Task%%nRunner
    if errorlevel 1 exit /b 1
)
java -Duser.language=en -Duser.country=US -cp out tests.VerificationTests
if errorlevel 1 exit /b 1
pause

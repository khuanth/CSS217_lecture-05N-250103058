#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p out
find src tests -name '*.java' | sort > sources.txt
if command -v javac >/dev/null 2>&1; then
    javac -encoding UTF-8 -d out @sources.txt
else
    java com.sun.tools.javac.Main -encoding UTF-8 -d out @sources.txt
fi
for task in 1 2 3 4 5; do
    java -Duser.language=en -Duser.country=US -cp out "task${task}.Task${task}Runner"
done
java -Duser.language=en -Duser.country=US -cp out tests.VerificationTests

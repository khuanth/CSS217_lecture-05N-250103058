package tests;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import task1.*;
import task2.*;
import task3.*;
import task4.*;
import task5.*;

public class VerificationTests {
    private static int passed;

    private static void check(boolean condition, String name) {
        if (!condition) throw new AssertionError(name);
        passed++;
    }

    private static void equal(double expected, double actual, String name) {
        check(Math.abs(expected - actual) < 0.000001, name);
    }

    private static void rejects(Runnable action, String name) {
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            passed++;
            return;
        }
        throw new AssertionError(name);
    }

    private static class CaptureExporter implements Exporter {
        String data;
        String destination;
        public void export(String destination, String data) {
            this.destination = destination;
            this.data = data;
        }
    }

    private static void task1() {
        String json = new JsonFormatter().format("A\"B\n", new String[]{"name"},
                new String[][]{{"x\\y\t\u0001"}});
        check(json.contains("A\\\"B\\n"), "JSON title escaping");
        check(json.contains("x\\\\y\\t\\u0001"), "JSON value escaping");
        check(new JsonFormatter().format("empty", new String[]{}, new String[][]{})
                .contains("\"records\": [\n ]"), "Empty JSON report");
        String csv = new CsvFormatter().format("CSV", new String[]{"name", "note"},
                new String[][]{{"a,b", "say \"hi\"\nnext"}});
        check(csv.equals("# TITLE: CSV\n\"name\",\"note\"\n\"a,b\",\"say \"\"hi\"\"\nnext\"\n"),
                "CSV separators, quotes and embedded newlines");
        rejects(() -> new JsonFormatter().format("x", new String[]{"a"},
                new String[][]{{}}), "Invalid JSON row");
        rejects(() -> new CsvFormatter().format("x", new String[]{"a"},
                new String[][]{{}}), "Invalid CSV row");
        String raw = "Сәлем";
        CaptureExporter first = new CaptureExporter();
        new Base64EncryptDecorator(new HeaderFooterDecorator(first, "fixed"))
                .export("test", raw);
        String encoded = Base64.getEncoder().encodeToString(raw.getBytes(StandardCharsets.UTF_8));
        check(first.data.equals("=== METADATA HEADER: fixed ===\n[BASE64_CIPHERTEXT:"
                + encoded + "]\n=== INTEGRITY CHECK: SHA-256 OK | END RECORD ==="),
                "Runner decorator order");
        check(first.destination.equals("test"), "Destination forwarding");
        CaptureExporter second = new CaptureExporter();
        new HeaderFooterDecorator(new Base64EncryptDecorator(second), "fixed")
                .export("test", raw);
        String decoded = new String(Base64.getDecoder().decode(second.data.substring(
                "[BASE64_CIPHERTEXT:".length(), second.data.length() - 1)), StandardCharsets.UTF_8);
        check(decoded.equals("=== METADATA HEADER: fixed ===\n" + raw
                + "\n=== INTEGRITY CHECK: SHA-256 OK | END RECORD ==="), "Reverse decorator order");
        rejects(() -> new Base64EncryptDecorator(null), "Null exporter");
    }

    private static void task2() throws Exception {
        final int[] upstreamCalls = {0};
        LegacyStockFeed feed = new LegacyStockFeed() {
            public String fetchRawTickerPacket(String ticker) {
                return "TICKER=" + ticker + "; BID=182.50; ASK=183.50; STATUS=OPEN;EXTRA=a=b";
            }
        };
        StockProvider adapter = new StockFeedAdapter(feed);
        equal(183, adapter.getMarketPrice("AAPL"), "Adapter midpoint");
        check(adapter.getStatus("AAPL").equals("OPEN"), "Adapter status");
        StockProvider provider = new StockProvider() {
            public double getMarketPrice(String ticker) {
                upstreamCalls[0]++;
                return upstreamCalls[0];
            }
            public String getStatus(String ticker) { return "OPEN"; }
        };
        StockProvider proxy = new CachedStockProxy(provider, 30);
        equal(1, proxy.getMarketPrice("AAPL"), "Cold cache");
        equal(1, proxy.getMarketPrice("AAPL"), "Hot cache");
        check(upstreamCalls[0] == 1, "Cache hit never calls upstream");
        equal(2, proxy.getMarketPrice("GOOGL"), "Independent ticker cache");
        Thread.sleep(80);
        equal(3, proxy.getMarketPrice("AAPL"), "Expired cache refresh");
        StockProvider noCache = new CachedStockProxy(provider, 0);
        noCache.getMarketPrice("AAPL");
        noCache.getMarketPrice("AAPL");
        check(upstreamCalls[0] == 5, "Zero TTL disables cache");
        rejects(() -> new CachedStockProxy(provider, -1), "Negative TTL");
        rejects(() -> new StockFeedAdapter(null), "Null legacy feed");
        rejects(() -> new CachedStockProxy(null, 10), "Null stock provider");
    }

    private static void task3() {
        DispatchStrategy hours = new BusinessHoursStrategy();
        check(!hours.shouldDispatch(1, 8), "Before working hours");
        check(hours.shouldDispatch(1, 9), "Opening boundary");
        check(hours.shouldDispatch(1, 17), "Closing boundary");
        check(!hours.shouldDispatch(1, 18), "After working hours");
        check(hours.shouldDispatch(5, 2), "Emergency bypass");
        check(new ImmediateStrategy().shouldDispatch(1, 2), "Immediate policy");
        final int[] deliveries = {0};
        MessageChannel channel = (recipient, message) -> deliveries[0]++;
        new DailySummaryAlert(channel, hours).processAlert("team", "digest", 23);
        check(deliveries[0] == 0, "Suppressed alert does not reach channel");
        new CriticalSystemAlert(channel, hours).processAlert("team", "incident", 2);
        new DailySummaryAlert(channel, hours).processAlert("team", "digest", 11);
        check(deliveries[0] == 2, "Bridge delegates allowed messages");
        check(new CriticalSystemAlert(channel, hours).getSeverityLevel() == 5, "Critical severity");
        rejects(() -> new DailySummaryAlert(null, hours), "Null channel");
    }

    private static void task4() {
        PricingService base = new CurrencyOrderAdapter(new LegacyForeignOrder("ORD-9821", 100),
                new LegacyCurrencyConverter(), "USD");
        equal(125, base.calculateTotal(), "Currency adaptation");
        PricingService wrapped = new GiftWrapDecorator(base);
        equal(130, wrapped.calculateTotal(), "Gift fee");
        PricingService shipped = new ExpressCourierDecorator(wrapped);
        equal(145, shipped.calculateTotal(), "Courier fee");
        PricingService taxed = new CustomsDutyDecorator(shipped);
        equal(157.33, taxed.calculateTotal(), "Customs and cent rounding");
        equal(125, base.calculateTotal(), "Base object remains reusable");
        equal(140.63, new GiftWrapDecorator(new CustomsDutyDecorator(base)).calculateTotal(),
                "Changing decorator order changes tax base");
        check(taxed.getReceiptBreakdown().endsWith(" + [Customs Duty: 8.5%]"), "Receipt stacking");
        rejects(() -> new GiftWrapDecorator(null), "Null pricing service");
    }

    private static void task5() {
        final int[] loads = {0};
        StorageDriver backend = new StorageDriver() {
            public byte[] loadRawBlob(String uri) { loads[0]++; return new byte[]{1, 2}; }
            public String getStorageType() { return "TEST"; }
        };
        for (String role : new String[]{"GUEST", "ROOT", "", null}) {
            StorageDriver proxy = new StorageDriverProxy(backend, new UserSession("user", role));
            check(proxy.loadRawBlob("asset").length == 0, "Reject unprivileged role: " + role);
        }
        check(loads[0] == 0, "Blocked requests never call backend");
        for (String role : new String[]{"ADMIN", "ENGINEER", "MEMBER"}) {
            StorageDriver proxy = new StorageDriverProxy(backend, new UserSession("user", role));
            check(proxy.loadRawBlob("asset").length == 2, "Authorized role: " + role);
            check(proxy.getStorageType().equals("PROXY_GUARDED(TEST)"), "Guarded driver identity");
        }
        check(loads[0] == 3, "Only authorized requests call backend");
        new VideoAsset(backend, "video").render();
        new AudioAsset(backend, "audio").render();
        check(loads[0] == 5, "Both asset types use interchangeable driver");
        rejects(() -> new StorageDriverProxy(null, new UserSession("u", "ADMIN")), "Null driver");
        rejects(() -> new StorageDriverProxy(backend, null), "Null session");
    }

    public static void main(String[] args) throws Exception {
        java.util.Locale.setDefault(java.util.Locale.US);
        task1();
        task2();
        task3();
        task4();
        task5();
        System.out.println("PASS: " + passed + " checks");
    }
}

package task1;

public class CsvFormatter implements ReportFormatter {
    private String quote(String value) {
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    private void appendRow(StringBuilder sb, String[] row) {
        for (int i = 0; i < row.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(quote(row[i]));
        }
        sb.append('\n');
    }

    @Override
    public String format(String title, String[] headers, String[][] rows) {
        StringBuilder sb = new StringBuilder("# TITLE: ");
        sb.append(title.replace("\r", " ").replace("\n", " ")).append('\n');
        appendRow(sb, headers);
        for (String[] row : rows) {
            if (row.length != headers.length) {
                throw new IllegalArgumentException("Row length must match headers");
            }
            appendRow(sb, row);
        }
        return sb.toString();
    }
}

package task1;

public class JsonFormatter implements ReportFormatter {
    private String escape(String value) {
        StringBuilder out = new StringBuilder();
        for (char c : value.toCharArray()) {
            switch (c) {
                case '"': out.append("\\\""); break;
                case '\\': out.append("\\\\"); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                default:
                if (c < 32) out.append(String.format("\\u%04x", (int) c));
                else out.append(c);
            }
        }
        return out.toString();
    }

    @Override
    public String format(String title, String[] headers, String[][] rows) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n \"report\": \"").append(escape(title)).append("\",\n \"records\": [\n");
        for (int i = 0; i < rows.length; i++) {
            if (rows[i].length != headers.length) {
                throw new IllegalArgumentException("Row length must match headers");
            }
            sb.append(" {");
            for (int j = 0; j < headers.length; j++) {
                sb.append("\"").append(escape(headers[j])).append("\": \"")
                .append(escape(rows[i][j])).append("\"");
                if (j < headers.length - 1) sb.append(", ");
            }
            sb.append("}").append(i < rows.length - 1 ? ",\n" : "\n");
        }
        sb.append(" ]\n}");
        return sb.toString();
    }
}

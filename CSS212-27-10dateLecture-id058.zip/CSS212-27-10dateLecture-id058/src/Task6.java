public class Task6 {
    public static void main(String[] args) {
        Hero swordKnight = new Knight(new Sword());
        Hero magicKnight = new Knight(new MagicWand());
        swordKnight.attack();
        magicKnight.attack();
    }

    interface Weapon {
        void use();
    }

    static class Sword implements Weapon {
        @Override
        public void use() {
            System.out.println("Slash! Dealing 20 physical damage.");
        }
    }

    static class MagicWand implements Weapon {
        @Override
        public void use() {
            System.out.println("Zap! Dealing 35 magic damage.");
        }
    }

    static abstract class Hero {
        protected Weapon weapon;

        public Hero(Weapon weapon) {
            this.weapon = weapon;
        }

        public abstract void attack();
    }

    static class Knight extends Hero {
        public Knight(Weapon weapon) {
            super(weapon);
        }

        @Override
        public void attack() {
            weapon.use();
        }
    }

    static class Wizard extends Hero {
        public Wizard(Weapon weapon) {
            super(weapon);
        }

        @Override
        public void attack() {
            weapon.use();
        }
    }
}

public class Task1 {
    public static void main(String[] args) {
        Image guestImage = new ProxyImage("salary_sheet.png", "GUEST");
        Image adminImage = new ProxyImage("salary_sheet.png", "ADMIN");
        guestImage.show();
        adminImage.show();
    }

    interface Image {
        void show();
    }

    static class RealImage implements Image {
        private final String fileName;

        public RealImage(String fileName) {
            this.fileName = fileName;

            System.out.println("--> [SLOW] Reading " + fileName + " from hard drive...");
        }

        @Override
        public void show() {
            System.out.println("Displaying " + fileName + " on screen!");
        }
    }

    static class ProxyImage implements Image {
        private final String fileName;
        private final String userRole;
        private RealImage realImage;

        public ProxyImage(String fileName, String userRole) {
            this.fileName = fileName;
            this.userRole = userRole;
        }

        @Override
        public void show() {

            if (!"ADMIN".equals(userRole)) {
                System.out.println("[ACCESS DENIED] You lack permission to view: " + fileName);
                return;
            }
            if (realImage == null) {
                realImage = new RealImage(fileName);
            }
            realImage.show();
        }
    }
}

public class Task5 {
    public static void main(String[] args) {
        PartyRemote partyRemote = new PartyRemote(new Radio());
        partyRemote.partyMode();
    }

    interface Device {
        void turnOn();
        void turnOff();
        void setVolume(int level);
    }

    static class Radio implements Device {
        @Override
        public void turnOn() {
            System.out.println("Radio starts playing static/music.");
        }

        @Override
        public void turnOff() {
            System.out.println("Radio shuts off.");
        }

        @Override
        public void setVolume(int level) {
            System.out.println("Radio volume knob turned to: " + level);
        }
    }

    static class BasicRemote {
        protected final Device device;

        public BasicRemote(Device device) {
            this.device = device;
        }

        public void powerOn() {
            device.turnOn();
        }

        public void powerOff() {
            device.turnOff();
        }

        public void setVolume(int level) {
            device.setVolume(level);
        }
    }

    static class PartyRemote extends BasicRemote {
        public PartyRemote(Device device) {
            super(device);
        }

        public void partyMode() {
            System.out.println("[Party Remote] Pumping up the party!");
            device.turnOn();
            device.setVolume(100);
        }
    }
}

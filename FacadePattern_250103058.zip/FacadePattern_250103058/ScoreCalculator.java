
public interface ScoreCalculator<T> {
    int compute(T record);
}

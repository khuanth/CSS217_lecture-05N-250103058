import java.util.ArrayList;
import java.util.List;
import java.util.function.ToIntFunction;
import java.util.stream.IntStream;


public class Main {

    static final int N = 200_000;
    static final int ROUNDS = 20;
    static volatile long sink;

    public static void main(String[] args) {
        trap1Autoboxing();
        trap2ArrayListSizing();
        trap3StringConcat();
        trap4StreamsInHotLoops();
    }


    interface BoxedCalculator<T> {
        Integer compute(T record);
    }

    static void trap1Autoboxing() {
        BoxedCalculator<String> bad = s -> s.length();
        ScoreCalculator<String> good = s -> s.length();
        ToIntFunction<String> std = String::length;
        String[] data = new String[1000];
        java.util.Arrays.fill(data, "hello world");

        report("Trap 1 BAD  (Integer)", () -> {
            long sum = 0;
            for (int i = 0; i < 5_000; i++) for (String s : data) sum += bad.compute(s);
            sink = sum;
        }, "Trap 1 GOOD (int)", () -> {
            long sum = 0;
            for (int i = 0; i < 5_000; i++) for (String s : data) sum += good.compute(s);
            sink = sum;
        });
        sink = std.applyAsInt("x");
    }

    static void trap2ArrayListSizing() {
        report("Trap 2 BAD  (new ArrayList<>())", () -> {
            List<String> records = new ArrayList<>();
            for (int i = 0; i < N; i++) records.add("r");
            sink = records.size();
        }, "Trap 2 GOOD (new ArrayList<>(N))", () -> {
            List<String> records = new ArrayList<>(N);
            for (int i = 0; i < N; i++) records.add("r");
            sink = records.size();
        });
    }


    static void trap3StringConcat() {
        List<String> tokens = new ArrayList<>();
        for (int i = 0; i < 5_000; i++) tokens.add("token" + i);

        report("Trap 3 BAD  (String +=)", () -> {
            String log = "";
            for (String t : tokens) log += t + ", ";
            sink = log.length();
        }, "Trap 3 GOOD (StringBuilder)", () -> {
            StringBuilder log = new StringBuilder(tokens.size() * 16);
            for (String t : tokens) log.append(t).append(", ");
            sink = log.length();
        });
    }

    static void trap4StreamsInHotLoops() {
        int[] data = IntStream.range(0, 1_000).toArray();

        report("Trap 4 stream  (IntStream per call)", () -> {
            long sum = 0;
            for (int i = 0; i < 20_000; i++) sum += IntStream.of(data).filter(x -> x % 2 == 0).sum();
            sink = sum;
        }, "Trap 4 for loop (counted)", () -> {
            long sum = 0;
            for (int i = 0; i < 20_000; i++) {
                int s = 0;
                for (int x : data) if (x % 2 == 0) s += x;
                sum += s;
            }
            sink = sum;
        });
        System.out.println("  (The JIT may optimize a simple stream or boxing so well that no gap shows.\n"
                + "   That is the handout's point: don't trust intuition, profile first.)\n");
    }

    static void report(String nameA, Runnable a, String nameB, Runnable b) {
        for (int i = 0; i < 5; i++) { a.run(); b.run(); }
        long ta = time(a), tb = time(b);
        System.out.printf("%-38s %8.2f ms%n", nameA, ta / 1e6);
        System.out.printf("%-38s %8.2f ms%n", nameB, tb / 1e6);
        System.out.println();
    }

    static long time(Runnable r) {
        long best = Long.MAX_VALUE;
        for (int i = 0; i < ROUNDS; i++) {
            long t0 = System.nanoTime();
            r.run();
            best = Math.min(best, System.nanoTime() - t0);
        }
        return best;
    }
}
